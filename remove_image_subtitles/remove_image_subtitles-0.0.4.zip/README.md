# Remove image subtitle streams

plugin for [Unmanic](https://github.com/Unmanic)
