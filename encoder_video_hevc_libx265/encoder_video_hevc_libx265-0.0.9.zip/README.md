# Video Encoder H265/HEVC - libx265

plugin for [Unmanic](https://github.com/Unmanic)
