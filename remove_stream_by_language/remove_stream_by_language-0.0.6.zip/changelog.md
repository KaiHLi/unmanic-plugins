**<span style="color:#56adda">0.0.5</span>**
- Process audio and subtitles
- Change to negative metadata stream selection

**<span style="color:#56adda">0.0.4</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.3</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.2</span>**
- Improve file detection on streams matching languages

**<span style="color:#56adda">0.0.1</span>**
- Initial version
