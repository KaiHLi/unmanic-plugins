
**<span style="color:#56adda">0.0.5</span>**
- Fix for incorrect lib import

**<span style="color:#56adda">0.0.4</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.3</span>**
- Enabled support for v2 plugin executor

**<span style="color:#56adda">0.0.2</span>**
- Fix bug in stream mapping causing subtitles from the previous file being added to the command of the current file

**<span style="color:#56adda">0.0.1</span>**
- Initial version
