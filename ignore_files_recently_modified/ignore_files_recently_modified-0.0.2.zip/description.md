
Times can be written as:

- **Milliseconds:** ms, millisecond, milliseconds
- **Seconds:** s, sec, secs, second, seconds
- **Minutes:** m, min, mins, minute, minutes
- **Hours:** h, hour, hours
- **Days:** d, day, days
- **Weeks:** w, week, weeks
- **Years:** y, year, years

---

#### Examples:

###### <span style="color:magenta">1 day</span>
'<span style="color:blue">1d</span>'
or 
'<span style="color:blue">1 day</span>'

###### <span style="color:magenta">2 hours, 30 minutes</span>
'<span style="color:blue">2.5 h</span>'
or 
'<span style="color:blue">2.5 hours</span>'
